#include "config.h"
#define NARROWCHAR
#include "history.c"
